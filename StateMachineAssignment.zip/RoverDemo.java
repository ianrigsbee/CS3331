import java.util.Random;
public class RoverDemo {

    public static void main(String[] args){
        boolean ran = runner();
        System.out.println(ran);
    }
    public static boolean runner(){
        Context context = new Context();
        Idle idle = new Idle();
        Reverse reverse = new Reverse();
        DeAccelerate deaccelerate = new DeAccelerate();
        DeAccelerateBackwards deaccelerateb = new DeAccelerateBackwards();
        ConstantSpeed constantspeed = new ConstantSpeed();
        AccelerateForward accelerateForward = new AccelerateForward();
        context.setState(idle);

        while(context.getState() != null){
            System.out.println("current state " + context.getState().toString());
            Random rn = new Random();
            int x = rn.nextInt((context.getState().getActions()))+1;

            System.out.println("Chose action: " + x);
            context.getState().updateState(context, x);
            System.out.println("going to next state");
        }
        System.out.println("Now exiting demo");
        return true;
    }
}
