public interface State {
    public void doAction(Context context);
    public int getActions();
    public void updateState(Context context, int x);
}
