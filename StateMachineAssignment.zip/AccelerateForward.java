public class AccelerateForward implements State {
    private static AccelerateForward instance = new AccelerateForward();
    @Override
    public void doAction(Context context){
        System.out.println("Accelerating forward");
        System.out.println("please choose an option");
        System.out.println("1. keep speeding accelerating");
        System.out.println("2. go into constant speed(hold right pedal for 5 seconds)");
        System.out.println("3. de-accelerate(Press right pedal twice)");
        System.out.println("4. exit program");
        context.setState(this);
    }
    public static AccelerateForward instance(){
        return instance;
    }
    @Override
    public String toString(){
        return "Accelerate forward state";
    }
    @Override
    public int getActions(){
        return 4;
    }

    @Override
    public void updateState(Context context, int x) {
        if(x == 1){
            context.setState(this);
        }else if(x == 2){
            context.setState(ConstantSpeed.instance());
        }else if(x == 3){
            context.setState(DeAccelerate.instance());
        }else if (x == 4){
            context.setState(null);
        }
    }
}
