public class Reverse implements State {
    private static Reverse instance = new Reverse();
    @Override
    public void doAction(Context context){
        System.out.println("Now going in reverse");
        System.out.println("please choose an option");
        System.out.println("1. keep reversing backwards");
        System.out.println("2. go into constant speed(hold right pedal for 5 seconds)");
        System.out.println("3. acclerate to zero(press right pedal twice)");
        System.out.println("4. exit program");
        context.setState(this);
    }
    @Override
    public String toString(){
        return "Reverse state";
    }
    @Override
    public int getActions(){
        return 4;
    }
    public static Reverse instance(){
        return instance;
    }

    @Override
    public void updateState(Context context, int x) {
        if(x == 1){
            context.setState(this);
        }else if(x == 2){
            context.setState(ConstantSpeed.instance());
        }else if(x == 3){
            context.setState(DeAccelerateBackwards.instance());
        }else if(x == 4){
            context.setState(null);
        }
    }
}
