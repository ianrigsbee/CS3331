public class DeAccelerateBackwards implements State {
    public static DeAccelerateBackwards instance = new DeAccelerateBackwards();
    public void doAction(Context context){
        System.out.println("accelerating to zero");
        System.out.println("please choose an option");
        System.out.println("1. keep accelerating to zero");
        System.out.println("2. go into constant speed(hold right pedal for 5 seconds)");
        System.out.println("3. exit program");
        context.setState(this);
    }
    public static DeAccelerateBackwards instance(){
        return instance;
    }
    public String toString(){
        return "DeAccelerate Backwards state";
    }
    @Override
    public int getActions(){
        return 3;
    }

    @Override
    public void updateState(Context context, int x) {
        if(x == 1){
            context.setState(this);
        }else if(x == 2){
            context.setState(ConstantSpeed.instance());
        }else if(x == 3){
            context.setState(null);
        }
    }
}
