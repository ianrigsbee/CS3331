public class Idle implements State{
    private static Idle instance = new Idle();
    @Override
    public void doAction(Context context){
        System.out.println("In Idle State");
        System.out.println("please choose an option");
        System.out.println("1. accelerate (Press right pedal once)");
        System.out.println("2. go in reverse(Hold left pedal for 5 seconds)");
        System.out.println("3. exit program");
        context.setState(this);

    }
    public static Idle instance(){
        return instance;
    }

    @Override
    public String toString(){
        return "Idle state";
    }
    @Override
    public int getActions(){
        return 3;
    }
    public void updateState(Context context, int x) {
        if(x == 1){
            context.setState(AccelerateForward.instance());
        }else if(x == 2){
            context.setState(Reverse.instance());
        }else if(x == 3){
            context.setState(null);
        }
    }

}
