import java.util.*;

/**
 * @author Ian
 * @version 1.5 (4/10/20)
 * @since version 1.0(3/15/20)
 */
public class Main {
    /*
    current assumptions
    1. Ive made the assumptions that if youre in De-Accelerate forward and De-Accelerate
    backwards that you should be able to go into constant speed from those states.
    2. Also the assumption that within constant speed you can go straight into accelerateforward
    and Reverse and reach those max speeds for those two states.


    The Sample run is the program. I didn't know how we were supposed to do a sample run so I
    turned the main into the sample run

     */

    /**
     * Main State goes into Idle for rover.
     * @author Ian
     * @version 1.5 (4/10/20)
     * @since version 1.0(3/15/20)
     * @param args
     * @see Idle()
     */
    public static void main(String[] args){
        Idle();
    }
    /**
     * User inputs an integer and returns it to be used in methods
     * for when user input is necessary.
     * @author Ian
     * @version 1.5 (4/10/20)
     * @since version 1.0(3/15/20)
     * @return returns and integer for user input in methods
     * @see Idle()
     * @see AccelerateForward()
     * @see DeAcclerate()
     * @see Reverse()
     * @see DeaccelerateBackwards()
     * @see ConstantSpeed()
     */
    public static int readinput(){
        Scanner in = new Scanner(System.in);
        int x = in.nextInt();
        return x;

    }
    /**
     * The idle state for the rover. uses user input
     * @author Ian
     * @version 1.5 (4/10/20)
     * @since version 1.0(3/15/20)
     * @returns a boolean to be used in user testing.
     * @see readinput()
     */
    public static boolean Idle(){

        System.out.println("now entering idle state");
        System.out.println("please choose an option");
        System.out.println("1. accelerate (Press right pedal once)");
        System.out.println("2. go in reverse(Hold left pedal for 5 seconds)");
        System.out.println("3. exit program");
        while(true) {
            int x = readinput();
            if (x == 1) {
                //AccelerateForward();
                return true;
            }
            if (x == 2) {
                //Reverse();
                return true;
            }
            if (x == 3) {
                return true;
                //System.exit(0);
            }
            //invalid input for testing purposes
            return false;
        }

    }
    /**
     * The AccelerateForward state. Uses user input. Enter method
     * from Idle() or ConstantSpeed()
     * @author Ian
     * @version 1.5 (4/10/20)
     * @since version 1.0(3/15/20)
     * @return a boolean value for testing
     * @see Idle()
     * @see ConstantSpeed()
     */
    public static boolean AccelerateForward(){
        System.out.println("now accelerating forward");
        System.out.println("please choose an option");
        System.out.println("1. keep speeding accelerating");
        System.out.println("2. go into constant speed(hold right pedal for 5 seconds)");
        System.out.println("3. de-accelerate(Press right pedal twice)");
        System.out.println("4. exit program");
        while(true){
            System.out.println("reading input, enter one of the options.");
            int input = readinput();
            if(input == 1) {
                return true;
                //System.out.println("increasing speed");
            }
            if(input == 2) {
                return true;
                //ConstantSpeed();
            }
            if(input == 3) {
                return true;
                //DeAccelerate();
            }
            if(input == 4) {
                return true;
                //System.exit(0);
            }
            //invalid input for testing purposes
            return false;
        }
    }
    /**
     * The DeAccelerate state. Uses user input. Enter state
     * from AccelerateForward()
     * @author Ian
     * @version 1.5 (4/10/20)
     * @since version 1.0(3/15/20)
     * @return a boolean value for testing purposes
     * @see AccelerateForward()
     */
    public static boolean DeAccelerate(){
        System.out.println("now Deaccelerating");
        System.out.println("please choose an option");
        System.out.println("1. keep de-accelerating");
        System.out.println("2. go into constant speed(hold right pedal for 5 seconds)");
        System.out.println("3. exit program");
        while(true){
            System.out.println("reading input, enter one of the options.");
            int input = readinput();
            if(input == 1) {
                System.out.println("Decrementing speed");
                return true;
            }
            if(input == 2) {
                return true;
                //ConstantSpeed();
            }
            if(input == 3) {
                return true;
                //System.exit(0);
            }
            //invalid input for testing purposes
            return false;
        }
    }
    /**
     * The reverse state for the drone. Uses user input. Enter state from Idle() and
     * ConstantSpeed()
     * @author Ian
     * @version 1.5 (4/10/20)
     * @since version 1.0(3/15/20)
     * @return a boolean value for testing purposes
     * @see Idle()
     * @see ConstantSpeed()
     */
    public static boolean Reverse(){
        System.out.println("now going in reverse");
        System.out.println("please choose an option");
        System.out.println("1. keep reversing backwards");
        System.out.println("2. go into constant speed(hold right pedal for 5 seconds)");
        System.out.println("3. acclerate to zero(press right pedal twice)");
        System.out.println("4. exit program");
        while(true){
            System.out.println("reading input, enter one of the options.");
            int input = readinput();
            if(input == 1) {
                System.out.println("Decrementing speed");
                return true;
            }
            if(input == 2) {
                return true;
                //ConstantSpeed();
            }
            if(input == 3) {
                return true;
                //DeaccelerateBackwards();
            }
            if(input == 4) {
                return true;
                //System.exit(0);
            }
            //invalid input for testing purposes
            return false;
        }

    }
    /**
     * DeAccelerate backwards, technically accelerating during the
     * reverse state. Uses user input. Enter state from Reverse().
     * @author Ian
     * @version 1.5 (4/10/20)
     * @since version 1.0(3/15/20)
     * @return a boolean value for testing purposes
     * @see Reverse()
     */
    public static boolean DeaccelerateBackwards(){
        System.out.println("now accelerating to zero");
        System.out.println("please choose an option");
        System.out.println("1. keep accelerating to zero");
        System.out.println("2. go into constant speed(hold right pedal for 5 seconds)");
        System.out.println("3. exit program");

        while(true){
            int input = readinput();
            if(input == 1) {
                System.out.println("Incrementing speed");
                return true;
            }
            if(input == 2) {
                return true;
                //ConstantSpeed();
            }
            if(input == 3) {
                return true;
                //System.exit(0);
            }
            //invalid input for purposes
            return false;
        }
    }
    /**
     * Rover is in constant speed. Uses user input. Enter state
     * from DeaccelerateBackwards(), DeAccelerate(),
     * Reverse(), and AccelerateForward().
     * @author Ian
     * @version 1.5 (4/10/20)
     * @since version 1.0(3/15/20)
     * @return a boolean value for testing purposes.
     * @see DeaccelerateBackwards()
     * @see DeAccelerate()
     * @see Reverse()
     * @see AccelerateForward
     */
    public static boolean ConstantSpeed(){
        System.out.println("now entering constant speed");
        System.out.println("please choose an option");
        System.out.println("1. accelerate (Press right pedal once)");
        System.out.println("2. go in reverse(Hold left pedal for 5 seconds)");
        System.out.println("3. exit program");
        while(true){
            int input = readinput();
            if(input == 1) {
                return true;
                //AccelerateForward();
            }
            if(input == 2) {
                return true;
                //Reverse();
            }
            if(input == 3) {
                return true;
                //System.exit(0);
            }
            //invalid input for purposes
            return false;
        }
    }

}
