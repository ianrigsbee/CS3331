import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.io.InputStream;


import static org.junit.Assert.*;

public class Maintest {
    /** run the test */
    public static void main(String[] args){
        org.junit.runner.JUnitCore.main("Maintest");
    }
    /** run test*/
    @Test
    public void IdleTest(){
        Main main = new Main();
        String input = "1";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);
        assertTrue(main.Idle());


    }
    @Test
    public void IdleTest1(){
        Main main = new Main();
        String input = "1";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);
        assertNotNull(main.Idle());

    }
    @Test
    public void Idle2(){
        Main main = new Main();
        String input = "5";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);
        assertFalse(main.Idle());

    }
    @Test
    public void AccelerateForwardTest(){
        Main main = new Main();
        String input = "1";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);
        assertTrue(main.AccelerateForward());
    }
    @Test
    public void AccelerateForwardTest1(){
        Main main = new Main();
        String input = "6";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);
        assertNotNull(main.AccelerateForward());
    }
    @Test
    public void AccelerateForwardTest2(){
        Main main = new Main();
        String input = "5";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);
        assertFalse(main.AccelerateForward());
    }
    @Test
    public void DeAccelerateTest(){
        Main main = new Main();
        String input = "1";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);
        assertEquals(true, main.DeAccelerate());
    }
    @Test
    public void DeAccelerateTest1(){
        Main main = new Main();
        String input = "7";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);
        assertFalse(main.DeAccelerate());
    }
    @Test
    public void DeAccelerateTest2(){
        Main main = new Main();
        String input = "5";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);
        assertEquals(false, main.DeAccelerate());
    }
    @Test
    public void ReverseTest(){
        Main main = new Main();
        String input = "1";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);
        assertEquals(true, main.Reverse());
    }
    @Test
    public void ReverseTest1(){
        Main main = new Main();
        String input = "1";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);
        assertNotNull(main.Reverse());
    }
    @Test
    public void ReverseTest2(){
        Main main = new Main();
        String input = "8";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);
        assertEquals(false, main.Reverse());
    }
    @Test
    public void DeaccelerateBackwardsTest(){
        Main main = new Main();
        String input = "1";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);
        assertEquals(true, main.DeaccelerateBackwards());
    }
    @Test
    public void DeaccelerateBackwardsTest1(){
        Main main = new Main();
        String input = "2";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);
        assertNotNull(main.DeaccelerateBackwards());
    }
    @Test
    public void DeaccelerateBackwardsTest2(){
        Main main = new Main();
        String input = "0";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);
        assertEquals(false, main.DeaccelerateBackwards());
    }
    @Test
    public void ConstantSpeedTest(){
        Main main = new Main();
        String input = "1";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);
        assertEquals(true, main.ConstantSpeed());
    }
    @Test
    public void ConstantSpeedTest1(){
        Main main = new Main();
        String input = "2";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);
        assertNotNull(main.ConstantSpeed());
    }
    @Test
    public void ConstantSpeedTest2(){
        Main main = new Main();
        String input = "9";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);
        assertEquals(false, main.ConstantSpeed());
    }
    @Test
    public void readinputTest(){
        Main main = new Main();
        String input = "1";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);
        assertEquals(1, main.readinput());
    }
    @Test
    public void readinputTest1(){
        Main main = new Main();
        String input = "2";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);
        assertNotNull(main.readinput());
    }
    @Test
    public void readinputTest2(){
        Main main = new Main();
        String input = "9";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);
        assertNotEquals(8, main.readinput());
    }

}
