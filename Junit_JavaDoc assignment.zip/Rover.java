public class Rover {
    private int currentspeed = 0;
    private final int maxspeed = 12;
    private final int maxbackspeed = -12;

    public Rover(){}

    public int getCurrentspeed(){
        return currentspeed;
    }
    public int getMaxspeed(){
        return maxspeed;
    }
    public int getMaxbackspeed(){
        return maxbackspeed;
    }
    public void incrementCurrentSpeed(){
        currentspeed = currentspeed + 2;
    }
    public void decrementCurrentSpeed(){
        currentspeed = currentspeed - 2;
    }
}
