public class Thread2 extends Thread {
    String[] playablesounds = {"re.wav", "fa.wav", "la.wav", "do-octave.wav"};
    @Override
    public void run(){
        FilePlayer filePlayer = new FilePlayer();
        for(int i = 0; i<playablesounds.length-1; i++){
            synchronized (filePlayer){
                filePlayer.play("src/Sounds/" + playablesounds[i]);
                try {
                    Thread.sleep(250);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            System.out.println(playablesounds[i]);
        }
        filePlayer.play("src/Sounds/" + playablesounds[playablesounds.length-1]);


    }
}
