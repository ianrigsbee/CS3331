import java.util.*;

public class Main {
    /*
    current assumptions
    1. Ive made the assumptions that if youre in De-Accelerate forward and De-Accelerate
    backwards that you should be able to go into constant speed from those states.
    2. Also the assumption that within constant speed you can go straight into accelerateforward
    and Reverse and reach those max speeds for those two states.


    The Sample run is the program. I didn't know how we were supposed to do a sample run so I
    turned the main into the sample run

     */
    public static void main(String[] args){
        Rover rover = new Rover();
        Idle(rover);
    }
    public static int readinput(){
        Scanner in = new Scanner(System.in);
        int x = in.nextInt();
        return x;

    }
    public static void Idle(Rover rover){

        System.out.println("now entering idle state");
        System.out.println("please choose an option");
        System.out.println("1. accelerate (Press right pedal once)");
        System.out.println("2. go in reverse(Hold left pedal for 5 seconds)");
        System.out.println("3. exit program");
        int x = readinput();
        if(x == 1) AccelerateForward(rover);
        if(x == 2) Reverse(rover);
        if(x == 3) System.exit(0);

    }
    public static void AccelerateForward(Rover rover){
        System.out.println("now accelerating forward");
        System.out.println("please choose an option");
        System.out.println("1. keep speeding accelerating");
        System.out.println("2. go into constant speed(hold right pedal for 5 seconds)");
        System.out.println("3. de-accelerate(Press right pedal twice)");
        System.out.println("4. exit program");
        while(rover.getCurrentspeed() != rover.getMaxspeed()){
            System.out.println("reading input, enter one of the options.");
            int input = readinput();
            if(input == 1) rover.incrementCurrentSpeed();
            if(input == 2) ConstantSpeed(rover);
            if(input == 3) DeAccelerate(rover);
            if(input == 4) System.exit(0);

        }
        System.out.println("reached max speed, now entering constant speed");
        ConstantSpeed(rover);
    }
    public static void DeAccelerate(Rover rover){
        System.out.println("now Deaccelerating");
        System.out.println("please choose an option");
        System.out.println("1. keep de-accelerating");
        System.out.println("2. go into constant speed(hold right pedal for 5 seconds)");
        System.out.println("3. exit program");
        while(rover.getCurrentspeed() != 0 && rover.getCurrentspeed() != rover.getMaxbackspeed()){
            System.out.println("reading input, enter one of the options.");
            int input = readinput();
            if(input == 1) rover.decrementCurrentSpeed();
            if(input == 2) ConstantSpeed(rover);
            if(input == 3) System.exit(0);
        }
        if(rover.getCurrentspeed() == 0) {
            System.out.println("reached 0 speed, entering idle state");
            Idle(rover);
        }
        if(rover.getCurrentspeed() == rover.getMaxbackspeed()){
            System.out.println("reached max reverse speed, entering constant speed");
            ConstantSpeed(rover);
        }
    }
    public static void Reverse(Rover rover){
        System.out.println("now going in reverse");
        System.out.println("please choose an option");
        System.out.println("1. keep reversing backwards");
        System.out.println("2. go into constant speed(hold right pedal for 5 seconds)");
        System.out.println("3. acclerate to zero(press right pedal twice)");
        System.out.println("4. exit program");
        while(rover.getCurrentspeed() != rover.getMaxbackspeed()){
            System.out.println("reading input, enter one of the options.");
            int input = readinput();
            if(input == 1) rover.decrementCurrentSpeed();
            if(input == 2) ConstantSpeed(rover);
            if(input == 3) DeaccelerateBackwards(rover);
            if(input == 4) System.exit(0);
        }
        System.out.println("reached max reverse speed, entering constant speed");
        ConstantSpeed(rover);

    }
    public static void DeaccelerateBackwards(Rover rover){
        System.out.println("now accelerating to zero");
        System.out.println("please choose an option");
        System.out.println("1. keep accelerating to zero");
        System.out.println("2. go into constant speed(hold right pedal for 5 seconds)");
        System.out.println("3. exit program");

        while(rover.getCurrentspeed() != 0 && rover.getCurrentspeed() != rover.getMaxspeed()){
            int input = readinput();
            if(input == 1) rover.incrementCurrentSpeed();
            if(input == 2) ConstantSpeed(rover);
            if(input == 3) System.exit(0);
        }
        if(rover.getCurrentspeed() == 0) {
            System.out.println("reached 0 km/h now going into idle state");
            Idle(rover);
        }
        if(rover.getCurrentspeed() == rover.getMaxspeed()){
            System.out.println("reached max forward speed, now entering constant state");
            ConstantSpeed(rover);
        }
    }
    public static void ConstantSpeed(Rover rover){
        System.out.println("now entering constant speed");
        System.out.println("please choose an option");
        System.out.println("1. accelerate (Press right pedal once)");
        System.out.println("2. go in reverse(Hold left pedal for 5 seconds)");
        System.out.println("3. exit program");
        while(true){
            int input = readinput();
            if(input == 1) AccelerateForward(rover);
            if(input == 2) Reverse(rover);
            if(input == 3) System.exit(0);
        }
    }

}
